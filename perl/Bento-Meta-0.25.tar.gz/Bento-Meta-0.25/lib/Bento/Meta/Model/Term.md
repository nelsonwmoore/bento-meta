# NAME

Bento::Meta::Model::Term - object that models a term from a terminology

# SYNOPSIS

# DESCRIPTION

# METHODS

- value(), set\_value($actual\_term\_string)
- origin\_id(), set\_origin\_id($name\_of\_term\_source)
- origin\_definition(), set\_origin\_definition($text\_definition\_from\_source)
- concept(), set\_concept($concept\_obj)

# SEE ALSO

[Bento::Meta::Model::Entity](/perl/lib/Bento/Meta/Model/Entity.md), [Bento::Meta::Model](/perl/lib/Bento/Meta/Model.md).

# AUTHOR

    Mark A. Jensen < mark -dot- jensen -at- nih -dot- gov >
    FNL
